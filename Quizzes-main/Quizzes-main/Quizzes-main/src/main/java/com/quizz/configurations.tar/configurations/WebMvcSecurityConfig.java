package com.quizz.configurations;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

import com.quizz.services.WebUserService;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Configuration
@EnableWebSecurity
public class WebMvcSecurityConfig {
    private final WebUserService webUserService;
    private final BCryptPasswordEncoder passwordEncoder;

    @Autowired
    public WebMvcSecurityConfig(WebUserService webUserService, BCryptPasswordEncoder passwordEncoder) {
	this.webUserService = webUserService;
	this.passwordEncoder = passwordEncoder;
    }

    private AuthenticationSuccessHandler roleBasedSuccessHandler() {
	return new AuthenticationSuccessHandler() {
	    @Override
	    public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response,
		    Authentication authentication) throws IOException, ServletException {
		Map<String, String> urls = new HashMap<>();
		urls.put("ROLE_ADMIN", "/admin/dashboard");
		urls.put("ROLE_USER", "/auth/welcome");

		List<GrantedAuthority> authorities = (List<GrantedAuthority>) authentication.getAuthorities();
		String role = authorities.get(0).getAuthority();
		String redirectUrl = urls.getOrDefault(role, "/auth/welcome");
		System.out.println("Role: " + role);
		response.sendRedirect(redirectUrl);
	    }
	};
    }

    // Cấu hình cho admin với độ ưu tiên cao hơn (Order 1)
    @Bean
    @Order(1)
    SecurityFilterChain adminFilterChain(HttpSecurity http) throws Exception {
	return http.securityMatcher("/admin/**") // Chỉ áp dụng cho /admin/**
		.csrf(csrf -> csrf.disable())
		.authorizeHttpRequests(auth -> auth
			.requestMatchers("/admin/login", "/", "/api/**", "/auth/login", "/auth/**", "/assets/**",
				"/css/**", "/js/**", "/img/**", "/webjars/**")
			.permitAll() // Cho phép truy cập /admin/login
			.requestMatchers("/admin/**").hasRole("ADMIN") // Các trang khác yêu cầu ROLE_ADMIN
			.anyRequest().authenticated())
		.formLogin(form -> form.loginPage("/admin/login").loginProcessingUrl("/admin/process-login")
			.usernameParameter("usernameOrEmail").passwordParameter("password")
			.successHandler(roleBasedSuccessHandler()).failureUrl("/admin/login?error").permitAll())
		.logout(logout -> logout.logoutRequestMatcher(new AntPathRequestMatcher("/admin/logout"))
			.logoutSuccessUrl("/admin/login?logout").permitAll())
		.exceptionHandling(ex -> ex.accessDeniedPage("/auth/access-denied")).build();
    }

    // Cấu hình cho các request khác (Order 2)
    @Bean
    @Order(2)
    SecurityFilterChain webFilterChain(HttpSecurity http) throws Exception {
	return http.securityMatcher(request -> !request.getRequestURI().startsWith("/api/"))
		.csrf(csrf -> csrf
			.ignoringRequestMatchers("/take-quiz/**"))
		.authorizeHttpRequests(
			auth -> auth.requestMatchers("/", "/api/**", "/auth/login", "/auth/**", "/assets/**", "/css/**",
				"/js/**", "/img/**", "/webjars/**").permitAll().anyRequest().authenticated())
		.formLogin(form -> form.loginPage("/auth/login").loginProcessingUrl("/auth/process-login")
			.usernameParameter("usernameOrEmail").passwordParameter("password")
			.successHandler(roleBasedSuccessHandler()).failureUrl("/auth/login?error").permitAll())
		.logout(logout -> logout.logoutRequestMatcher(new AntPathRequestMatcher("/auth/logout"))
			.logoutSuccessUrl("/auth/login?logout").permitAll())
		.exceptionHandling(ex -> ex.accessDeniedPage("/auth/access-denied")).build();
    }

    @Autowired
    public void configureGlobal(AuthenticationManagerBuilder builder) throws Exception {
	builder.userDetailsService(webUserService).passwordEncoder(passwordEncoder);
    }
}